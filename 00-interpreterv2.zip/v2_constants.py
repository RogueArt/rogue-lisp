from typing import List, Dict, Union, Annotated
BrewinAsPythonValue = Union[None, int, str, bool, 'ObjectDefinition']

debug = 0